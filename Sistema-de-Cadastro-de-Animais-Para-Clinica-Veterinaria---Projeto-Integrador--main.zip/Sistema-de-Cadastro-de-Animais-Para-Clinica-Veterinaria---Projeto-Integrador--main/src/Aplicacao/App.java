package Aplicacao;

import Classes.TelaInicial;

public class App{
    public static void main(String[] args) {
        TelaInicial telaMenu = new TelaInicial();
    }
}